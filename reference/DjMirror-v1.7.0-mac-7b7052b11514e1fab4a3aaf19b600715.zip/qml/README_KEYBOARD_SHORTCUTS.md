# Traktor Mirror Window Keyboard Shortcuts

## View Control
- `V` - Toggle between full and mini view
- `A` - Toggle window decorations (frame)
- `Shift+D` - Toggle debug viewer visibility
- `Shift+K` - Show/hide debug viewer completely

## Deck Control
- `D` - Switch between decks
- `S` - Toggle sequencer
- `F` - Show/hide effects list

## Navigation
- `L` - Show browser to load a track
- `C` - Show settings view
- `Shift+P` - Show plugin settings

## Playback
- `P` - Toggle play/pause (through touch control panel)

## Touch Control Panel Actions
The touch control panel provides additional functionality when visible:
- View Selection - Switch between full and mini view
- Deck Selection - Switch between decks
- Load - Show browser to load a track
- Settings - Show settings view
- Window Maximize - Toggle between normal and maximized window states
- FX - Show/hide effects selector
- Play - Toggle playback
- Sequencer - Toggle sequencer

## Notes
- The touch control panel can be shown/hidden by clicking in the top center area of the window
- Some shortcuts may only work when the touch control panel is visible
- The debug viewer can be useful for troubleshooting and monitoring system logs 