import QtQuick
import QtQuick.Window 2.15
import Qt5Compat.GraphicalEffects

import CSI 1.0
import Traktor.Gui 1.0 as Traktor

Item {
    id: keyboard
    
    // Señal que se emite cuando se pulsa Enter
    signal enterPressed(string text)
    
    property real screenScale: 1.0
    
    property string currentText: ""

    property bool isShiftPressed: false
    property bool isAltGrPressed: false
    property bool isCapsLock: false
    
    // Referencia al objeto prefs para logging
    property var prefs
    
    // Referencias de utilidad
    property var colors: QtObject {
        property color primary: "#FF6600"      // Naranja Traktor
        property color secondary: "#00AAFF"    // Azul brillante
        property color background: "#111111"   // Fondo oscuro
        property color backgroundAlt: "#222222" // Gris oscuro
        property color textPrimary: "#FFFFFF"  // Texto blanco
        property color textSecondary: "#DDDDDD" // Texto gris claro
        property color accent: "#33FF33"       // Verde brillante
        property color keyNormal: "#333333"    // Color normal de tecla
        property color keyHover: "#444444"     // Color hover de tecla
        property color keySpecialNormal: "#444444" // Color normal de tecla especial
        property color keySpecialHover: "#555555"  // Color hover de tecla especial
    }

    // Componente para las teclas
    component KeyButton : Rectangle {
        property string keyText: ""
        property string altText: ""  // Texto alternativo para cuando Shift está pulsado
        property bool isSpecial: false
        
        property var onClick: function() {}
        
        width: 35 * screenScale
        height: 35 * screenScale
        color: isSpecial ? colors.keySpecialNormal : colors.keyNormal
        radius: 2 * screenScale
        
        Behavior on color {
            ColorAnimation { duration: 100 }
        }

        Column {
            anchors.centerIn: parent
            spacing: 1 * screenScale

            // Texto alternativo (arriba)
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: altText
                visible: altText !== ""
                color: keyboard.isShiftPressed ? colors.primary : "gray"
                font.pixelSize: (isSpecial ? 10 : 12) * screenScale
                font.bold: keyboard.isShiftPressed
            }

            // Texto principal (abajo)
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: keyText
                color: "white"
                font.pixelSize: (isSpecial ? 12 : 14) * screenScale
                font.bold: !keyboard.isShiftPressed && altText !== ""
            }
        }
        
        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onEntered: parent.color = isSpecial ? colors.keySpecialHover : colors.keyHover
            onExited: parent.color = isSpecial ? colors.keySpecialNormal : colors.keyNormal
            onClicked: onClick()
        }
    }
    
    width: 420 * screenScale
    height: 220 * screenScale
    
    // Campo de texto
    TextInput {
        id: textInput
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 6 * screenScale
        height: 16 * screenScale
        color: colors.textPrimary
        font.pixelSize: 14 * screenScale
        readOnly: true
        text: keyboard.currentText
    }
    
    // Teclado
    Column {
        anchors.top: textInput.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.margins: 6 * screenScale
        spacing: 2 * screenScale
        
        // Fila de números
        Row {
            spacing: 2 * screenScale
            Repeater {
                model: [
                    {key: "1", alt: "!"},
                    {key: "2", alt: "@"},
                    {key: "3", alt: "#"},
                    {key: "4", alt: "$"},
                    {key: "5", alt: "%"},
                    {key: "6", alt: "&"},
                    {key: "7", alt: "/"},
                    {key: "8", alt: "("},
                    {key: "9", alt: ")"},
                    {key: "0", alt: "="},
                    {key: "", alt: ""}
                ]
                delegate: KeyButton {
                    keyText: modelData.key
                    altText: modelData.alt
                    onClick: function() { 
                        if (modelData.key) {
                            keyboard.currentText += keyboard.isShiftPressed ? modelData.alt : modelData.key
                        }
                    }
                }
            }
        }
        
        // Fila de letras Q-P
        Row {
            spacing: 2 * screenScale
            Repeater {
                model: ["q", "w", "e", "r", "t", "y", "u", "i", "o", "p", ""]
                delegate: KeyButton {
                    keyText: keyboard.isCapsLock ? modelData.toUpperCase() : modelData
                    onClick: function() { if (modelData) keyboard.currentText += keyboard.isCapsLock ? modelData.toUpperCase() : modelData }
                }
            }
        }
        
        // Fila de letras A-L
        Row {
            spacing: 2 * screenScale
            Repeater {
                model: ["a", "s", "d", "f", "g", "h", "j", "k", "l", "ñ", ""]
                delegate: KeyButton {
                    keyText: keyboard.isCapsLock ? modelData.toUpperCase() : modelData
                    onClick: function() { if (modelData) keyboard.currentText += keyboard.isCapsLock ? modelData.toUpperCase() : modelData }
                }
            }
        }
        
        // Fila de letras Z-M
        Row {
            spacing: 2 * screenScale
            Repeater {
                model: [
                    {key: "z", alt: ""},
                    {key: "x", alt: ""},
                    {key: "c", alt: ""},
                    {key: "v", alt: ""},
                    {key: "b", alt: ""},
                    {key: "n", alt: "<"},
                    {key: "m", alt: ">"},
                    {key: ",", alt: ";"},
                    {key: ".", alt: ":"},
                    {key: "-", alt: "_"},
                    {key: "", alt: ""}
                ]
                delegate: KeyButton {
                    keyText: ["n", "m", ",", ".", "-"].includes(modelData.key) ? modelData.key : 
                            (keyboard.isCapsLock ? modelData.key.toUpperCase() : modelData.key)
                    altText: modelData.alt
                    onClick: function() {
                        if (modelData.key) {
                            if (["n", "m", ",", ".", "-"].includes(modelData.key)) {
                                keyboard.currentText += keyboard.isShiftPressed ? modelData.alt : modelData.key
                            } else {
                                keyboard.currentText += keyboard.isCapsLock ? modelData.key.toUpperCase() : modelData.key
                            }
                        }
                    }
                }
            }
        }
        
        // Fila de teclas especiales
        Row {
            spacing: 2 * screenScale
            
            // Tecla Shift
            KeyButton {
                width: 35 * screenScale
                keyText: "Shift"
                isSpecial: true
                onClick: function() { keyboard.isShiftPressed = !keyboard.isShiftPressed }
            }

            // Tecla AltGr
            KeyButton {
                width: 35 * screenScale
                keyText: "AltGr"
                isSpecial: true
                onClick: function() { keyboard.isAltGrPressed = !keyboard.isAltGrPressed }
            }
            
            // Tecla Caps Lock
            KeyButton {
                width: 72 * screenScale
                keyText: "Caps"
                isSpecial: true
                color: keyboard.isCapsLock ? colors.primary : colors.keySpecialNormal
                onClick: function() { keyboard.isCapsLock = !keyboard.isCapsLock }
            }
            
            // Tecla Backspace
            KeyButton {
                width: 72 * screenScale
                keyText: "←"
                isSpecial: true
                onClick: function() { keyboard.currentText = keyboard.currentText.slice(0, -1) }
            }
            
            // Tecla Espacio
            KeyButton {
                width: 109 * screenScale
                keyText: "Space"
                isSpecial: true
                onClick: function() { keyboard.currentText += " " }
            }
            
            // Tecla Enter
            KeyButton {
                width: 72 * screenScale
                keyText: "↵"
                isSpecial: true
                onClick: function() {
                    if (keyboard.currentText.length > 0) {
                        keyboard.enterPressed(keyboard.currentText)
                        keyboard.currentText = ""
                    }
                }
            }
        }
    }
}
