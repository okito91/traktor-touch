import QtQuick
import QtQuick.Window 2.15
import Qt5Compat.GraphicalEffects

import CSI 1.0
import Traktor.Gui 1.0 as Traktor

// Overlay visual avanzado para el plugin - sin funcionalidad de arrastre
Item {
    id: keyboardOverlay
    
    // Señal que se emite cuando se pulsa Enter en el teclado
    signal textEntered(string text)

    // Señal que se emite cuando se oculta el overlay
    signal overlayHidden()
    
    property bool autoHide: false
    property int displayTime: 0  // 0 = mostrar siempre
    property string title: "TOUCH KEYBOARD"  // Añadir propiedad title
    
    // Factor de escala para adaptarse a diferentes resoluciones
    property real screenScale: 1.0
    
    // Referencia al objeto prefs para logging
    property var prefs
    
    // Efectos visuales
    property bool enableGlowEffect: true
    property bool enableDropShadow: true
    property bool enableBlurEffect: false
    
    // Referencias de utilidad
    property var colors: QtObject {
        property color primary: "#FF6600"      // Naranja Traktor
        property color secondary: "#00AAFF"    // Azul brillante
        property color background: "#111111"   // Fondo oscuro
        property color backgroundAlt: "#222222" // Gris oscuro
        property color textPrimary: "#FFFFFF"  // Texto blanco
        property color textSecondary: "#DDDDDD" // Texto gris claro
        property color accent: "#33FF33"       // Verde brillante
    }

    // Propiedades internas
    property bool _isActive: true
    property real _opacity: 1.0
    
    // Visibilidad
    width: mainPanel.width
    height: mainPanel.height
    visible: _isActive
    opacity: _isActive ? _opacity : 0.0
    
    // Propiedades para asegurar que el overlay no se salga de la pantalla
    property bool preventOffscreen: true
    
    // Observar cambios en las propiedades del padre para reposicionar
    onParentChanged: {
        if (parent) {
            centerOverlay();
            // Conectarse a cambios en el tamaño del padre
            parent.widthChanged.connect(centerOverlay);
            parent.heightChanged.connect(centerOverlay);
        }
    }
    
    // Observar cambios propios de tamaño
    onWidthChanged: centerOverlay()
    onHeightChanged: centerOverlay()
    
    // Panel principal
    Rectangle {
        id: mainPanel
        width: keyboard.width + (20 * screenScale)
        height: keyboard.height + titleBar.height + (4 * screenScale)
        radius: 10 * screenScale
        color: colors.background
        opacity: _opacity
        
        // Borde
        border.width: 3 * screenScale
        border.color: colors.primary
        
        // Efecto de glow
        Rectangle {
            id: glowBorder
            anchors.fill: parent
            radius: parent.radius
            color: "transparent"
            border.width: 2 * screenScale
            border.color: colors.primary
            visible: enableGlowEffect
            opacity: 0.0
            
            SequentialAnimation on opacity {
                running: enableGlowEffect
                loops: Animation.Infinite
                NumberAnimation { from: 0.0; to: 1.0; duration: 1200; easing.type: Easing.InOutQuad }
                NumberAnimation { from: 1.0; to: 0.0; duration: 1200; easing.type: Easing.InOutQuad }
            }
        }

        // Título del panel
        Rectangle {
            id: titleBar
            anchors.top: parent.top
            anchors.left: parent.left
            anchors.right: parent.right
            height: 36 * screenScale
            color: colors.primary
            radius: 10 * screenScale
            
            // Ajustar las esquinas para que solo sea redondeada en la parte superior
            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: parent.radius
                color: parent.color
            }
            
            Text {
                id: titleText
                text: keyboardOverlay.title
                color: "white"
                font.pixelSize: 16 * screenScale
                font.bold: true
                anchors.centerIn: parent
            }
            
            // Botón de cerrar
            Rectangle {
                id: closeButton
                width: 22 * screenScale
                height: 22 * screenScale
                radius: 11 * screenScale
                color: "#FF3333"
                anchors.right: parent.right
                anchors.rightMargin: 7 * screenScale
                anchors.verticalCenter: parent.verticalCenter
                
                Text {
                    anchors.centerIn: parent
                    text: "×"
                    color: "white"
                    font.pixelSize: 18 * screenScale
                    font.bold: true
                }
                
                // Mantener solamente este MouseArea para la funcionalidad del botón cerrar
                MouseArea {
                    id: closeButtonArea
                    anchors.fill: parent
                    onClicked: hideOverlay()
                    z: 1000
                }
            }
        }
        
        // Componente Keyboard
        Keyboard {
            id: keyboard
            anchors.top: titleBar.bottom
            anchors.bottom: parent.bottom
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.margins: 1 * screenScale
            screenScale: keyboardOverlay.screenScale
            prefs: keyboardOverlay.prefs

            onEnterPressed: {
                keyboardOverlay.textEntered(text)
                hideOverlay()  // Siempre cerramos el overlay al pulsar Enter
            }
        }
        
        // Efecto de sombra
        layer.enabled: enableDropShadow
        layer.effect: DropShadow {
            horizontalOffset: 3 * screenScale
            verticalOffset: 3 * screenScale
            radius: 8.0 * screenScale
            samples: 16
            color: "#80000000"
        }
    }
    
    // Animación de entrada/salida
    Behavior on opacity {
        NumberAnimation { 
            duration: 400
            easing.type: Easing.OutCubic
        }
    }
    
    // Timer para auto-ocultar
    Timer {
        id: hideTimer
        interval: displayTime
        repeat: false
        running: autoHide && displayTime > 0
        onTriggered: {
            hideOverlay();
        }
    }
    
    // Mostrar el overlay
    function showOverlay() {
        prefs.log("INFO", "Mostrando keyboard overlay")
        _isActive = true;
        if (autoHide && displayTime > 0) {
            hideTimer.restart();
        }
    }
    
    // Ocultar el overlay
    function hideOverlay() {
        prefs.log("INFO", "Ocultando keyboard overlay")
        _isActive = false;
        // Emitir señal cuando se oculta el overlay
        overlayHidden();
    }
    
    // Cuando el componente se completa, mostrar el overlay
    Component.onCompleted: {
        showOverlay();
        // Centrar explícitamente al inicio
        centerOverlay();
    }
    
    // Función para centrar el overlay en la pantalla
    function centerOverlay() {
        if (!parent) return;
        
        // Obtener las dimensiones disponibles
        var availableWidth = parent.width;
        var availableHeight = parent.height;
        
        // Calcular posición centrada
        var newX = Math.max(0, Math.min((availableWidth - width) / 2, availableWidth - width));
        var newY = Math.max(0, Math.min((availableHeight - height) / 2, availableHeight - height));
        
        // Aplicar posición
        x = newX;
        y = newY;
    }
} 
