import QtQuick
import QtQuick.Window 2.15

import CSI 1.0
import Traktor.Gui 1.0 as Traktor

// Plugin avanzado con overlay interactivo
QtObject {
    id: keyboardPlugin

    // Información del plugin
    property string name: "Keyboard Plugin"
    property string fileName: "KeyboardPlugin"
    property string version: "1.0.1"
    property string author: "DJ Tools"
    property string description: "Advanced Keyboard"
    
    // Estado del plugin
    property bool isEnabled: true
    property bool isInitialized: false
    
    // Señal para emitir eventos
    signal signalEmitted(string signalName, var data)
    
    // Referencia a la vista actual
    property var currentView: null
    property var overlayInstance: null
    
    // Datos del deck
    property int deckId: 0
    
    // Referencia al objeto prefs para logging
    property var prefs: QtObject {
        function log(level, message) {
            prefs.log("[KeyboardPlugin] " + level + ": " + message)
        }
    }  

    property real screenScale: 1.0

    // Se llama cuando el plugin se carga
    function onLoad() {

    }

    // Se llama cuando el plugin se inicializa en una vista
    function initializeInView(view) {
        if (!view) {
            return;
        }
        
        currentView = view;
        
        // Obtener el deckId de la vista si está disponible
        if (view.focusDeckId !== undefined) {
            deckId = view.focusDeckId;
        }
        
        try {
            // Intentar cargar el overlay desde archivo externo primero
            var component = Qt.createComponent("PluginOverlay.qml");
            
            if (component.status === Component.Ready) {
                // Crear la instancia del overlay
                overlayInstance = component.createObject(currentView, {
                    "title": "KEYBOARD",
                    "isShiftPressed": false,
                    "isAltGrPressed": false,
                    "isCapsLock": false,
                    "enableGlowEffect": true,
                    "enableDropShadow": true,
                    "screenScale": keyboardPlugin.screenScale,
                    "_isActive": true,
                    "prefs": keyboardPlugin.prefs
                });

                // Conectar la señal textEntered
                if (overlayInstance) {
                    overlayInstance.textEntered.connect(function(text) {
                        prefs.log("INFO", "Texto ingresado: " + text);
                        // Emitir señal al PluginManager
                        signalEmitted("textEntered", { text: text });
                    });
                }
                
            } else if (component.status === Component.Error) {
                prefs.log("ERROR", "Error al cargar el componente: " + component.errorString());
            }
        } catch (e) {
            prefs.log("ERROR", "Error al inicializar el plugin: " + e);
        }
    }
    
    // Se llama cuando el plugin se descarga
    function onUnload() {        
        if (overlayInstance) {
            // Si el overlay tiene un método para ocultarse, lo usamos
            if (typeof overlayInstance.hideOverlay === "function") {
                overlayInstance.hideOverlay();
            }
            
            overlayInstance.destroy();
            overlayInstance = null;
        }
        
        isInitialized = false;
    }
} 