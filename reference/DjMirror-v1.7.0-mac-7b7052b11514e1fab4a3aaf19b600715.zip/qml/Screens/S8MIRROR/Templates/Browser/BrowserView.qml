import CSI 1.0
import QtQuick
import QtQml
import Traktor.Gui 1.0 as Traktor
import QtQml.Models

import './../' as Templates
import './../../Views/Browser' as BrowserView

import './../../Views/Widgets' as Widgets

import '../../../../Defines'
import '../../../../Screens/Defines'

//----------------------------------------------------------------------------------------------------------------------
//                                            BROWSER VIEW
//
// Vista principal del navegador de Traktor que permite explorar y cargar pistas.
//
// Características principales:
//  - Conectado al QBrowser de Traktor para recibir el modelo de datos
//  - Navegación fluida por la biblioteca
//  - Soporte para ordenamiento personalizado
//  - Indicadores visuales de compatibilidad de key/BPM
//  - Modo de desplazamiento rápido
//
// Propiedades principales:
//  - isActive: Estado de activación del browser
//  - pageSize: Número de items visibles (7 o 9 según preferencias)
//  - focusColor: Color de resaltado según deck seleccionado
//  - sortingId/Direction: Control de ordenamiento
//
// Componentes principales:
//  1. ListView (contentList):
//     - Muestra la lista de elementos navegables
//     - Soporta scroll suave y selección
//     - Delegates personalizados por tipo de item
//
//  2. BrowserHeader:
//     - Muestra ruta de navegación actual
//     - Indicador de deck seleccionado
//     - Iconos de estado
//
//  3. BrowserFooter:
//     - Controles de ordenamiento
//     - Información adicional
//     - Estado de filtros
//
//  4. ScrollBar:
//     - Indicador visual de posición
//     - Animaciones suaves
//     - Color según deck activo
//
// Funcionalidades:
//  - Navegación por nodos (enterNode/exitNode)
//  - Scroll rápido con centrado automático
//  - Animaciones fluidas de UI
//  - Obtención de key del deck master
//  - Soporte para debug
//
// Comportamiento:
//  - Muestra/oculta scrollbar automáticamente
//  - Adapta layout según preferencias
//  - Mantiene selección visible
//  - Soporta modo zebra para listas cortas
//----------------------------------------------------------------------------------------------------------------------

Templates.View {
  id: qmlBrowser
  
  // Señal que se emite cuando se carga una pista
  signal trackLoaded(int deckId)

  // Señal que se emite cuando se navega a una pista
  signal trackNavigated(int deckId)

  property real screenScale: prefs.screenScale

  property int    focusDeckId: 0

  property string propertiesPath: ""
  property bool  isActive:      false
  property bool  enterNode:     false
  property bool  exitNode:      false
  property int   increment:     0
  property color focusColor:    (qmlBrowser.focusDeckId < 2) ? colors.colorDeckBright : colors.colorWhite
  property int   speed:         150
  property real  sortingKnobValue:  0
  property int   pageSize:          prefs.displayMoreItems ? 9 : 7
  property int   fastScrollCenter:  3
  property bool  previewPlayerLoadOrPlay: false  // Nueva propiedad para controlar la preescucha

  // Propiedades para el reproductor de vista previa
  AppProperty { id: previewIsLoaded;     path: "app.traktor.browser.preview_player.is_loaded" }
  AppProperty { id: previewTrackLength;  path: "app.traktor.browser.preview_content.track_length" }
  AppProperty { id: previewTrackElapsed; path: "app.traktor.browser.preview_player.elapsed_time" }
  AppProperty { id: previewPlayerLoad;   path: "app.traktor.browser.preview_player.load" }
  AppProperty { id: previewPlayerUnload; path: "app.traktor.browser.preview_player.unload" }

  readonly property int  maxItemsOnScreen: prefs.displayMoreItems ? 9 : 7

  // This is used by the footer to change/display the sorting!
  property alias sortingId:         browser.sorting
  property alias sortingDirection:  browser.sortingDirection
  property alias isContentList:     browser.isContentList
  property alias currentIndex:      browser.currentIndex
  property alias contentCurrentIndex: contentList.currentIndex

  anchors.fill: parent

  // Mapping property
  //MappingProperty { id: browserViewMode; path: "mapping.state.browser_view_mode" }

  // App properties
  AppProperty { id: deckAKeyDisplay; path: "app.traktor.decks.1.track.key.resulting.quantized" }
  AppProperty { id: deckBKeyDisplay; path: "app.traktor.decks.2.track.key.resulting.quantized" }
  AppProperty { id: deckCKeyDisplay; path: "app.traktor.decks.3.track.key.resulting.quantized" }
  AppProperty { id: deckDKeyDisplay; path: "app.traktor.decks.4.track.key.resulting.quantized" }
  AppProperty { id: masterDeckId;    path: "app.traktor.masterclock.source_id" }


  //--------------------------------------------------------------------------------------------------------------------
  // On increment changed
  onIncrementChanged: {
    if (qmlBrowser.increment != 0) {
      var newValue = clamp(browser.currentIndex + qmlBrowser.increment, 0, contentList.count - 1);
  
      // center selection if user is _fast scrolling_ but we're at the _beginning_ or _end_ of the list
      if(qmlBrowser.increment >= pageSize) {
        var centerTop = fastScrollCenter;

        if(browser.currentIndex < centerTop) {          
          newValue = centerTop;
        }
      }
      if(qmlBrowser.increment <= (-pageSize)) {
        var centerBottom = contentList.count - 1 - fastScrollCenter;

        if(browser.currentIndex > centerBottom) {          
          newValue = centerBottom;
        }
      }

      browser.changeCurrentIndex(newValue);
      qmlBrowser.increment = 0;
      doScrolling();
    }      
  }

  //--------------------------------------------------------------------------------------------------------------------
  // On exit node
  onExitNodeChanged: {
    if (qmlBrowser.exitNode) {
      browser.exitNode()
    }
    
    qmlBrowser.exitNode = false;
  }

  // On enter node
  onEnterNodeChanged: {
    if (qmlBrowser.enterNode) {
      var movedDown = browser.enterNode(qmlBrowser.focusDeckId, contentList.currentIndex);
      if (movedDown) { 
        browser.relocateCurrentIndex()
      }
    }

    qmlBrowser.enterNode = false;
  }

  // Función para cargar la pista seleccionada en el deck activo
  function loadSelectedTrack() {
    if (browser.isContentList && contentList.currentIndex >= 0) {
      var movedDown = browser.enterNode(qmlBrowser.focusDeckId, contentList.currentIndex);
      if (!movedDown) {
        // Si no se movió hacia abajo, significa que se cargó una pista
        // Emitir la señal trackLoaded
        qmlBrowser.trackLoaded(qmlBrowser.focusDeckId);
      }
    }
  }

  // Clamps a value between a minimum and a maximum
  function clamp(val, min, max){
    return Math.max(min, Math.min(val, max));
  }

  //--------------------------------------------------------------------------------------------------------------------
  // Behavior on scrolling
  //
  // On Scrolling, show scrolling-bar and hide header/footer. After some seconds, go back to initial state.
  //--------------------------------------------------------------------------------------------------------------------

  // Do scrolling
  function doScrolling() { 
    scrollbar.opacity = 1; 
    opacityTimer.restart(); 
  }

  //--------------------------------------------------------------------------------------------------------------------

  Timer {
    id: opacityTimer
    interval: 800  // duration of the scrollbar opacity
    repeat:   false
  
    onTriggered: { 
      scrollbar.opacity = 0; 
    }
  }


  //--------------------------------------------------------------------------------------------------------------------
  // VIEWS / ITEMS
  //--------------------------------------------------------------------------------------------------------------------

  // Browser
  Traktor.Browser {
    id: browser
    isActive: qmlBrowser.isActive
  }
 
  //--------------------------------------------------------------------------------------------------------------------
  //  LIST VIEW -- NEEDS A MODEL CONTAINING THE LIST OF ITEMS TO SHOW AND A DELEGATE TO DEFINE HOW ONE ITEM LOOKS LIKE
  //-------------------------------------------------------------------------------------------------------------------

  // zebra filling up the rest of the list if smaller than maxItemsOnScreen
  Grid {
    anchors.top:            contentList.top
    anchors.right:          parent.right
    anchors.left:           parent.left
    columns:                1
    spacing:                1 * screenScale  

    Repeater {
      model: (contentList.count < qmlBrowser.maxItemsOnScreen) ? (qmlBrowser.maxItemsOnScreen - contentList.count) : 0
      Rectangle { 
        color: ((contentList.count + index) % 2 == 0) ? colors.colorGrey08 : "transparent"
        width: qmlBrowser.width
        height: prefs.displayMoreItems ? 25 * screenScale : 32 * screenScale
      }
    }
  }

  //--------------------------------------------------------------------------------------------------------------------
  // Browser header - Mover antes del ListView
  BrowserView.BrowserHeader {
    id: browserHeader
    z: 2  // Asegurar que está por encima del ListView
    nodeIconId:     browser.iconId
    currentDeck:    qmlBrowser.focusDeckId
    state:          "show"
    pathStrings:    browser.currentPath 

    Behavior on height { NumberAnimation { duration: speed; } }

    screenScale: qmlBrowser.screenScale
  }

  //--------------------------------------------------------------------------------------------------------------------
  // Content list
  ListView {
    id: contentList
    z: 1  // Asegurar que está por debajo del header y footer
    anchors.top:              browserHeader.bottom
    anchors.left:             parent.left
    anchors.right:            parent.right
    anchors.bottom:           browserFooter.top  // Añadir anclaje al footer
    verticalLayoutDirection:  ListView.TopToBottom

    // Ajustar los márgenes y altura considerando el screenScale
    anchors.topMargin:        3 * screenScale
    height:                   (qmlBrowser.pageSize * (prefs.displayMoreItems ? 26 : 33)) * screenScale - (1 * screenScale) // adjust for spacing
    clip: false // true
    spacing:                  1 * screenScale

    // Desactivar el centrado automático
    preferredHighlightBegin: 0
    preferredHighlightEnd: 0
    highlightRangeMode: ListView.NoHighlightRange
    highlightMoveDuration:    0
    delegate: BrowserView.ListDelegate {
      id: listDelegate
      screenFocus: screen.focusDeckId
      height: (prefs.displayMoreItems ? 25 : 32) * screenScale
      matchesSearchFilter: qmlBrowser.matchesFilter(model, qmlBrowser.searchFilter)
    }
    model: browser.dataSet
    currentIndex: browser.currentIndex
    focus: true
    cacheBuffer: 0

    // Asegurar que el ListView tiene foco para recibir eventos de teclado
    Component.onCompleted: {
        focus = true;
    }

    // Cleanup al destruir el componente
    Component.onDestruction: {
      if (pluginManager && pluginManager.onPluginSignal) {
        try {
          pluginManager.onPluginSignal.disconnect(handlePluginSignal);
          prefs.log("INFO", "BrowserView desconectado de PluginManager");
        } catch (e) {
          // Ignorar errores de desconexión
        }
      }
    }
  }

  //--------------------------------------------------------------------------------------------------------------------
  // Botón de carga para interfaz táctil - Reemplazado por TouchButtonRound
  Widgets.TouchButtonRound {
    id: loadButton
    anchors.left: parent.left
    anchors.bottom: browserFooter.top
    anchors.bottomMargin: 6 * screenScale
    anchors.rightMargin: 6 * screenScale
    
    // Usar las propiedades del componente TouchButtonRound
    text: "LOAD"
    icon: "📥"
    isActive: false
    
    // Color del botón según el deck seleccionado
    color: qmlBrowser.focusColor
    
    // Solo mostrar cuando haya pistas que cargar
    visible: browser.isContentList
    
    // Manejar eventos del botón
    onClicked: {
      loadSelectedTrack();
      //filterByWords("lilli");
    }
    
    onPressed: {
      isActive = true;
    }
    
    onReleased: {
      isActive = false;
    }
  }

  // Botón para mostrar/ocultar el teclado virtual
  Widgets.TouchButtonRound {
    id: keyboardButton
    anchors.left: loadButton.right
    anchors.leftMargin: 6 * screenScale
    anchors.bottom: browserFooter.top
    anchors.bottomMargin: 6 * screenScale

    // Usar las propiedades del componente TouchButtonRound
    text: "KEYB"
    icon: "⌨️"
    isActive: false

    // Color del botón según el deck seleccionado
    color: qmlBrowser.focusColor

    // Solo mostrar cuando haya pistas que cargar
    visible: browser.isContentList

    // Manejar eventos del botón
    onClicked: {
      // Llamar a la función del MirrorWindow para toggle del teclado
      if (typeof mirrorWindow !== "undefined" && typeof mirrorWindow.toggleVirtualKeyboard === "function") {
        mirrorWindow.toggleVirtualKeyboard()
      } else {
        prefs.log("ERROR", "No se puede acceder a la función toggleVirtualKeyboard del mirrorWindow")
      }
    }

    onPressed: {
      isActive = true
    }

    onReleased: {
      isActive = false
    }
  }

  // Botón para salir del browser
  Widgets.TouchButtonRound {
    id: exitButton
    anchors.left: keyboardButton.right
    anchors.leftMargin: 6 * screenScale
    anchors.bottom: browserFooter.top
    anchors.bottomMargin: 6 * screenScale

    // Usar las propiedades del componente TouchButtonRound
    text: "EXIT"
    icon: "❌"
    isActive: false

    // Color del botón según el deck seleccionado
    color: qmlBrowser.focusColor

    // Solo mostrar cuando haya pistas que cargar
    visible: browser.isContentList

    // Manejar eventos del botón
    onClicked: {
      showDeckView()
    }

    onPressed: {
      isActive = true;
    }

    onReleased: {
      isActive = false;
    }
  }

  //--------------------------------------------------------------------------------------------------------------------
  // Browser footer - Mover después del ListView
  BrowserView.BrowserFooter {
    id: browserFooter
    z: 2  // Asegurar que está por encima del ListView
    state:        "show"
    propertiesPath: qmlBrowser.propertiesPath
    sortingKnobValue: qmlBrowser.sortingKnobValue

    Behavior on height { NumberAnimation { duration: speed; } }

    screenScale: qmlBrowser.screenScale
  }

  //--------------------------------------------------------------------------------------------------------------------
  // Scrollbar
  Widgets.ScrollBar {
    id: scrollbar
    z: 3  // Asegurar que está por encima de todo
    flickable:    contentList
    opacity:      0
    handleColor:  parent.focusColor
    Behavior on opacity { NumberAnimation { duration: (opacity == 0) ? 0 : speed; } }
  }

  //--------------------------------------------------------------------------------------------------------------------
  // NOTE: Supress show/hide for now, but KEEP this code. 
  //       The "come back" is planned for a later release!
  //--------------------------------------------------------------------------------------------------------------------
  // Shows the header and footer
  function showHeaderFooterAnimated(animated) {
    var defaultSpeed = qmlBrowser.speed;
    qmlBrowser.speed = (animated) ? qmlBrowser.speed : 0
    browserHeader.state = "show"
    browserFooter.state = "show"
    qmlBrowser.speed = defaultSpeed;
  }

  //--------------------------------------------------------------------------------------------------------------------

  // Hides the header and footer
  function hideHeaderFooterAnimated(animated) {
    var defaultSpeed = qmlBrowser.speed;
    qmlBrowser.speed = (animated) ? qmlBrowser.speed : 0
    browserHeader.state = "hide"
    browserFooter.state = "hide"
    qmlBrowser.speed = defaultSpeed;
  }

  // Obtains the master key from the master deck
  function getMasterKey() {
    switch (masterDeckId.value) {
      case 0: return deckAKeyDisplay.value;
      case 1: return deckBKeyDisplay.value;
      case 2: return deckCKeyDisplay.value;
      case 3: return deckDKeyDisplay.value;
    }

    return "";
  }

  //--------------------------------------------------------------------------------------------------------------------
  //  SIMPLE FILTERING SYSTEM
  //--------------------------------------------------------------------------------------------------------------------

  property string searchFilter: ""  // Nueva propiedad para el filtro de búsqueda

  // Función para determinar si un elemento del modelo cumple con el filtro
  function matchesFilter(modelItem, filterText) {
    if (!filterText || filterText.trim() === "") {
      return true; // Sin filtro, mostrar todo
    }

    if (!modelItem) {
      return false; // Sin elemento, ocultar
    }

    var searchText = filterText.toLowerCase().trim();

    // Construir el texto de búsqueda basado en las propiedades del modelo
    var itemText = "";

    // Si hay texto combinado, usarlo prioritariamente
    if (modelItem.combinedText) {
      itemText = modelItem.combinedText;
    }
    // Para pistas: "Artista - Título"
    else if (modelItem.artistName && modelItem.trackName) {
      itemText = modelItem.artistName + " - " + modelItem.trackName;
    }
    // Para carpetas u otros elementos: nodeName
    else if (modelItem.nodeName) {
      itemText = modelItem.nodeName;
    }
    // Fallback a otras propiedades
    else if (modelItem.title) {
      itemText = modelItem.title;
    }
    else if (modelItem.name) {
      itemText = modelItem.name;
    }

    itemText = String(itemText).toLowerCase();

    // Verificar si todas las palabras de búsqueda están en el texto del elemento
    var searchWords = searchText.split(/\s+/);
    for (var i = 0; i < searchWords.length; i++) {
      var word = searchWords[i].trim();
      if (word !== "" && itemText.indexOf(word) === -1) {
        // No mostrar logs de debug para evitar saturación
        return false; // Esta palabra no se encuentra
      }
    }

    // Solo mostrar log cuando hay un match (menos frecuente)
    if (searchText.length > 0) {
      prefs.log("DEBUG", "[BrowserView] MATCH: '" + itemText + "' contiene '" + searchText + "'");
    }

    return true; // Todas las palabras encontradas
  }

  function filterByWords(words) {
    prefs.log("INFO", "=== CAMBIO DE FILTRO ===");

    var newFilter = words || ""; // Asegurar que sea string vacío si es null/undefined
    searchFilter = newFilter;
    prefs.log("INFO", "Nuevo valor: '" + searchFilter + "'");

    // Si hay un filtro activo, posicionarse en el primer elemento que coincide
    if (newFilter && newFilter.trim() !== "") {
      navigateToFirstMatchingItem();
    }

    // Forzar actualización del ListView
    //contentList.forceLayout();

    // Mostrar estadísticas del filtrado
    //showFilterStats();

    // Mostrar ejemplo de datos del model
    //showModelData();
  }

  // Función para mostrar estadísticas del filtrado
  function showFilterStats() {
    prefs.log("INFO", "=== ESTADÍSTICAS DEL FILTRO ===");

    var originalCount = browser.dataSet ? browser.dataSet.rowCount() : 0;
    var visibleCount = contentList.count;
    var filterActive = searchFilter && searchFilter.trim() !== "";

    prefs.log("INFO", "Elementos totales en modelo: " + originalCount);
    prefs.log("INFO", "Elementos visibles en lista: " + visibleCount);
    prefs.log("INFO", "Filtro aplicado: '" + (searchFilter ? searchFilter.trim() : "") + "'");
    prefs.log("INFO", "Estado del filtro: " + (filterActive ? "ACTIVO" : "INACTIVO"));

    // Mostrar información adicional si el filtro está activo
    if (filterActive) {
      var filterWords = searchFilter.trim().split(/\s+/).filter(function(word) {
        return word.trim() !== "";
      });
      prefs.log("INFO", "Palabras en filtro: " + filterWords.length + " (" + filterWords.join(", ") + ")");

      if (originalCount > 0 && visibleCount === 0) {
        prefs.log("WARNING", "Filtro activo pero ningún elemento visible - posible problema de datos");
      }
    }
  }

  // Navega al primer elemento que coincide con el filtro actual
  function navigateToFirstMatchingItem() {
    if (!searchFilter || searchFilter.trim() === "") {
      return; // No hay filtro activo
    }

    try {
      // Ejecutar diagnóstico del modelo primero
      //showModelData();

      var totalCount = browser.dataSet.rowCount ? browser.dataSet.rowCount() : 0;
      prefs.log("INFO", "Buscando primer elemento coincidente entre " + totalCount + " elementos");
      prefs.log("DEBUG", "Tipo del modelo: " + typeof browser.dataSet);

      // Buscar el primer elemento que coincide con el filtro usando QAbstractTableModel
      if (typeof browser.dataSet.data === "function" && typeof browser.dataSet.index === "function") {
        prefs.log("DEBUG", "Usando QAbstractTableModel con data() e index()");

        // Primero determinar qué roles contienen datos de texto (basado en el primer elemento)
        var textRoles = [];
        try {
          var testIndex = browser.dataSet.index(0, 0);
          for (var testRole = 256; testRole < 280; testRole++) {
            try {
              var testData = browser.dataSet.data(testIndex, testRole);
              if (testData !== undefined && testData !== null && testData !== "" &&
                  typeof testData === "string" && testData.length > 0 && testData.length < 100) {
                textRoles.push(testRole);
                prefs.log("DEBUG", "Rol " + testRole + " contiene texto: '" + testData + "'");
              }
            } catch (e) {
              // Ignorar
            }
          }
          prefs.log("INFO", "Encontrados " + textRoles.length + " roles con datos de texto: " + textRoles.join(", "));
        } catch (e) {
          prefs.log("ERROR", "Error determinando roles de texto: " + e.message);
          // Usar roles por defecto si falla la detección
          textRoles = [256, 257, 258, 259, 260, 261, 262];
        }

        // Ahora buscar elementos que coincidan
        var elementsProcessed = 0;
        var elementsWithText = 0;

        for (var i = 0; i < totalCount; i++) {
          try {
            var modelIndex = browser.dataSet.index(i, 0);
            var modelItem = {};
            var allTextData = [];

            // Obtener TODOS los datos de texto posibles de este elemento
            for (var role = 256; role < 280; role++) {
              try {
                var value = browser.dataSet.data(modelIndex, role);
                if (value !== undefined && value !== null && value !== "" &&
                    typeof value === "string" && value.length > 0 && value.length < 200) {
                  allTextData.push(value);
                }
              } catch (e) {
                // Ignorar errores de roles individuales
              }
            }

            elementsProcessed++;

            if (allTextData.length > 0) {
              elementsWithText++;

              // Asignar las primeras propiedades de texto encontradas
              if (allTextData.length > 0) modelItem.artistName = allTextData[0];
              if (allTextData.length > 1) modelItem.trackName = allTextData[1];
              if (allTextData.length > 2) modelItem.nodeName = allTextData[2];
              if (allTextData.length > 3) modelItem.title = allTextData[3];
              if (allTextData.length > 4) modelItem.name = allTextData[4];

              // Crear un campo adicional con todo el texto combinado para búsqueda
              modelItem.combinedText = allTextData.join(" ");

              // Log solo para elementos que podrían coincidir (contienen el filtro o son los primeros)
              var containsFilter = modelItem.combinedText.toLowerCase().includes(searchFilter.toLowerCase());
              if (containsFilter || i < 3 || (i % 20 === 0)) {
                prefs.log("DEBUG", "Elemento " + i + " - texto combinado: '" + modelItem.combinedText + "' (coincide: " + containsFilter + ")");
              }

              if (matchesFilter(modelItem, searchFilter)) {
                prefs.log("INFO", "Encontrado elemento coincidente en índice " + i + ", navegando...");
                browser.changeCurrentIndex(i);
                doScrolling();
                return;
              }
            } else if (i < 5) {
              prefs.log("DEBUG", "Elemento " + i + " - sin datos de texto");
            }

          } catch (e) {
            prefs.log("DEBUG", "Error procesando elemento " + i + ": " + e.message);
          }
        }

        prefs.log("INFO", "Procesados " + elementsProcessed + " elementos, " + elementsWithText + " con datos de texto");
      } else {
        prefs.log("ERROR", "No se puede acceder al modelo - ni data() ni index() disponibles");
      }

      prefs.log("INFO", "No se encontró ningún elemento coincidente con el filtro '" + searchFilter + "'");

    } catch (e) {
      prefs.log("ERROR", "Error al navegar al primer elemento coincidente: " + e.message);
    }
  }

  function showModelData() {
    prefs.log("INFO", "=== DIAGNÓSTICO DETALLADO DEL MODELO ===");

    try {
      if (!browser.dataSet) {
        prefs.log("ERROR", "No hay modelo de datos disponible");
        return;
      }

      var totalCount = browser.dataSet.rowCount ? browser.dataSet.rowCount() : 0;
      prefs.log("INFO", "Total de elementos en el modelo: " + totalCount);
      prefs.log("INFO", "Filtro actual aplicado: '" + searchFilter + "'");
      prefs.log("INFO", "Elementos visibles en ListView: " + contentList.count);

      if (totalCount === 0) {
        prefs.log("WARNING", "El modelo está vacío");
        return;
      }

      // Información sobre el tipo de modelo
      prefs.log("INFO", "Tipo del modelo: " + (browser.dataSet.constructor ? browser.dataSet.constructor.name : "desconocido"));

      // Métodos disponibles
      var methods = [];
      if (typeof browser.dataSet.get === "function") methods.push("get(index)");
      if (typeof browser.dataSet.rowCount === "function") methods.push("rowCount()");
      if (typeof browser.dataSet.data === "function") methods.push("data(index, role)");
      if (typeof browser.dataSet.index === "function") methods.push("index(row, column)");
      if (typeof browser.dataSet.roleNames === "function") methods.push("roleNames()");
      prefs.log("INFO", "Métodos disponibles: " + (methods.length > 0 ? methods.join(", ") : "ninguno identificado"));

      // Propiedades disponibles
      var properties = [];
      if (browser.dataSet.length !== undefined) properties.push("length: " + browser.dataSet.length);
      if (browser.dataSet.count !== undefined) properties.push("count: " + browser.dataSet.count);
      prefs.log("INFO", "Propiedades: " + (properties.length > 0 ? properties.join(", ") : "ninguna identificada"));

      // Intentar acceder a un elemento de ejemplo (solo el primero)
      if (totalCount > 0) {
        prefs.log("INFO", "=== INTENTANDO ACCEDER AL PRIMER ELEMENTO ===");

        // Método 1: ListModel.get()
        if (typeof browser.dataSet.get === "function") {
          try {
            var item1 = browser.dataSet.get(0);
            prefs.log("INFO", "get(0) funciona - tipo: " + typeof item1);
            if (item1) {
              var props = Object.keys(item1).slice(0, 5); // Solo primeras 5 propiedades
              prefs.log("INFO", "Propiedades del elemento: " + props.join(", "));
            }
          } catch (e) {
            prefs.log("ERROR", "get(0) falló: " + e.message);
          }
        }

        // Método 2: Acceso directo por índice
        try {
          var item2 = browser.dataSet[0];
          if (item2 !== undefined) {
            prefs.log("INFO", "dataSet[0] funciona - tipo: " + typeof item2);
          } else {
            prefs.log("INFO", "dataSet[0] retorna undefined");
          }
        } catch (e) {
          prefs.log("ERROR", "dataSet[0] falló: " + e.message);
        }

        // Método 3: QAbstractTableModel con data() - probar diferentes roles
        if (typeof browser.dataSet.data === "function" && typeof browser.dataSet.index === "function") {
          try {
            var modelIndex = browser.dataSet.index(0, 0);
            prefs.log("INFO", "index(0,0) funciona - tipo: " + typeof modelIndex);

            // Probar diferentes roles comunes en Qt - más exhaustivo
            var rolesToTest = [];
            // Agregar roles estándar
            rolesToTest.push(0); // Qt::DisplayRole
            // Agregar Qt::UserRole y siguientes (256+)
            for (var ur = 0; ur < 20; ur++) {
              rolesToTest.push(256 + ur);
            }

            prefs.log("DEBUG", "Probando " + rolesToTest.length + " roles...");
            var foundData = [];
            for (var r = 0; r < rolesToTest.length; r++) {
              var role = rolesToTest[r];
              try {
                var data = browser.dataSet.data(modelIndex, role);
                if (data !== undefined && data !== null && data !== "") {
                  var dataStr = String(data);
                  if (dataStr.length > 0 && dataStr.length < 200) { // Evitar logs muy largos
                    prefs.log("INFO", "data(index, " + role + ") funciona - valor: '" + dataStr + "' (tipo: " + typeof data + ")");
                    foundData.push({role: role, value: dataStr, type: typeof data});
                  }
                }
              } catch (e) {
                // Solo log de error para roles que realmente fallan, no para todos
                if (r < 5) { // Solo log errores para los primeros roles
                  prefs.log("DEBUG", "data(index, " + role + ") falló: " + e.message);
                }
              }
            }
            prefs.log("INFO", "Encontrados " + foundData.length + " roles con datos en el elemento 0");

            // Intentar obtener roleNames si está disponible
            if (typeof browser.dataSet.roleNames === "function") {
              try {
                var roleNames = browser.dataSet.roleNames();
                prefs.log("INFO", "roleNames() disponible - tipo: " + typeof roleNames);
                if (typeof roleNames === "object" && roleNames !== null) {
                  var roleKeys = Object.keys(roleNames);
                  prefs.log("INFO", "Encontrados " + roleKeys.length + " roles nombrados");
                  for (var k = 0; k < Math.min(roleKeys.length, 8); k++) {
                    var roleKey = roleKeys[k];
                    var roleName = roleNames[roleKey];
                    var dataForRole = browser.dataSet.data(modelIndex, parseInt(roleKey));
                    if (dataForRole !== undefined && dataForRole !== "") {
                      prefs.log("INFO", "Role " + roleKey + " ('" + roleName + "'): '" + dataForRole + "'");
                    }
                  }
                }
              } catch (e) {
                prefs.log("ERROR", "roleNames() falló: " + e.message);
              }
            } else {
              prefs.log("INFO", "roleNames() no disponible");
            }

          } catch (e) {
            prefs.log("ERROR", "data()/index() general falló: " + e.message);
          }
        }

        // Método 4: Verificar si es un array
        if (Array.isArray(browser.dataSet)) {
          prefs.log("INFO", "El modelo es un Array de JavaScript");
        } else if (browser.dataSet instanceof Object) {
          prefs.log("INFO", "El modelo es un Object - posibles keys: " + Object.keys(browser.dataSet).slice(0, 3).join(", "));
        }
      }

    } catch (e) {
      prefs.log("ERROR", "Error en diagnóstico del modelo: " + e.message);
    }
  }

  //--------------------------------------------------------------------------------------------------------------------
  //  BETA: Pruebas del sistema de búsquedas
  //--------------------------------------------------------------------------------------------------------------------

  // Añadir el manejador para previewPlayerLoadOrPlay
  onPreviewPlayerLoadOrPlayChanged: {
    if (previewPlayerLoadOrPlay) {
      if (previewIsLoaded.value) {
        // Si ya está cargado, reproducir/pausar
        previewPlayerLoad.value = true;
      } else {
        // Si no está cargado, cargar la pista seleccionada
        previewPlayerLoad.value = true;
      }
      previewPlayerLoadOrPlay = false;
    }
  }
}

