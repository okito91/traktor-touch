# Script para detectar procesos en ejecución
Write-Host "Detectando procesos en ejecución..." -ForegroundColor Yellow

# Obtener todos los procesos en ejecución
$procesos = Get-Process | Where-Object {
    $_.SessionId -ne 0 -and  # Excluir procesos del sistema
    $_.Name -notmatch (
        "svchost|" +         # Servicios del sistema
        "System|" +          # Sistema
        "Idle|" +            # Proceso inactivo
        "Registry|" +        # Registro
        "fontdrvhost|" +     # Controlador de fuentes
        "csrss|" +           # Subsistema de tiempo de ejecución
        "smss|" +            # Gestor de sesiones
        "wininit|" +         # Inicio de Windows
        "services|" +        # Servicios
        "lsass|" +           # Seguridad de Windows
        "winlogon"           # Inicio de sesión
    )
} | Sort-Object Name

# Mostrar los procesos encontrados
Write-Host "`nProcesos en ejecución:" -ForegroundColor Cyan
Write-Host "=====================" -ForegroundColor Cyan

foreach ($proceso in $procesos) {
    # Obtener información de la ruta del proceso si está disponible
    try {
        $ruta = $proceso.MainModule.FileName
    } catch {
        $ruta = "Ruta no accesible"
    }
    
    Write-Host ("`nNombre: " + $proceso.Name) -ForegroundColor Green
    Write-Host ("PID: " + $proceso.Id)
    Write-Host ("Memoria (MB): " + [math]::Round($proceso.WorkingSet64 / 1MB, 2))
    Write-Host ("Ruta: " + $ruta)
    Write-Host ("Tiempo de CPU: " + $proceso.CPU)
    Write-Host ("Prioridad: " + $proceso.PriorityClass)
    Write-Host "-----------------------"
}

Write-Host "`nTotal de procesos detectados: $($procesos.Count)" -ForegroundColor Yellow
Write-Host "`nPresiona cualquier tecla para salir..." -ForegroundColor Cyan
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
